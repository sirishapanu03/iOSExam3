//
//  ResultViewController.swift
//  Exam03Practice
//
//  Created by Sirisha Panuganti on 11/29/23.
//

import UIKit

class ResultViewController: UIViewController {

    @IBOutlet weak var wordOL: UILabel!
    
    @IBOutlet weak var meaningOL: UILabel!
    
    var word = ""
    var meaning = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        wordOL.text! = word
        meaningOL.text! = meaning
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
