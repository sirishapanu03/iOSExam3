//
//  ViewController.swift
//  Exam03Practice
//
//  Created by Sirisha Panuganti on 11/29/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        word.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableviewOL.dequeueReusableCell(withIdentifier: "cell",for: indexPath)
        
        cell.textLabel?.text = word[indexPath.row][0]
        return cell
        
    }
    

    @IBOutlet weak var tableviewOL: UITableView!
    
    var word = [["Benevolent 🤗","Well-meaning and kindly"],["Courage 🦸‍♂️","The ability to do something that frightens one."],["Genuine 🌼","ruly what something is said to be; authentic."],["Hope 🌟","A feeling of expectation and desire for paticular thing to happen."],["Resilient 🌱", "Able to withstand or recover quickly from difficult conditions."],["Sad 😢",  "Feeling or showing sorrow; unhappy."],["Serene 🌅",  "Calm, Peaceful, and untrobuled."],["Joy 😊", "A feeling of great pleasure and happiness"],["Kindness 💖","The quality of being friendly,generous, and considerate."],["Peace ✌️","A state of tranquility or quiet"]]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //assign the number of rows to the table view OL
        tableviewOL.delegate = self
        //assigning datasource
        tableviewOL.dataSource = self
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition  = segue.identifier
        
        if(transition == "resultSegue")
        {
            let destination = segue.destination as! ResultViewController
            
            destination.word = word[(tableviewOL.indexPathForSelectedRow?.row)!][0]
            destination.meaning = word[(tableviewOL.indexPathForSelectedRow?.row)!][1]
            
        }
    }
}

