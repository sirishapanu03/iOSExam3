//
//  MovieCollectionViewCell.swift
//  Panuganti_Movies
//
//  Created by Sirisha Panuganti on 11/27/23.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var imageOL: UIImageView!
    
    func assignMovies(movie: Movie){
        imageOL.image = movie.MovieImage
    }
    
}
