//
//  ViewController.swift
//  Panuganti_Movies
//
//  Created by Sirisha Panuganti on 11/27/23.
//

import UIKit

class ViewController: UIViewController , UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return genrArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cels = genreTableView.dequeueReusableCell(withIdentifier: "sectionCell", for: indexPath)
        
        //populate a cell with data
        cels.textLabel?.text = genrArray[indexPath.row].MovieCategory
        //return the cell
        
        
        return cels
    }

    @IBOutlet weak var genreTableView: UITableView!
    var genrArray = gen
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        genreTableView.delegate = self
        genreTableView.dataSource = self
        self.title = "Movies App"
        
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "movieSegue"{
            
            let destination = segue.destination as! MoviesViewController
            
            //send the selected product row
            
            destination.moviesArray = genrArray[(genreTableView.indexPathForSelectedRow?.row)!].movies
            
            destination.title = genrArray[(genreTableView.indexPathForSelectedRow?.row)!].MovieCategory
        }
        
    }

}

