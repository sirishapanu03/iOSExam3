//
//  MovieData.swift
//  Panuganti_Movies
//
//  Created by Sirisha Panuganti on 11/27/23.
//

import Foundation
import UIKit
struct Movie{
    let MovieTitle:String
    let MovieImage:UIImage
    let releasedYear:String
    let MovieRating:String
    let boxOffice:String
    let moviePlot:String
    var cast: [String] = []
}

struct Genre{
    var MovieCategory : String
    var movies:[Movie] = []
}

let genre1 = Genre(MovieCategory: "Family", movies: [
    Movie(MovieTitle: "SVSC", MovieImage: UIImage(named: "SVSC")!, releasedYear: "2013", MovieRating: "6", boxOffice: "217", moviePlot: "The story revolves around a lovable family headed by Prakash Raj",cast: ["Venkatesh, Mahesh"]),
    Movie(MovieTitle: "Ala Vaikuntapuramlo", MovieImage: UIImage(named: "AVPL")!, releasedYear: "2020", MovieRating: "7", boxOffice: "91", moviePlot: "Fate plays a vital role in connecting the life of Bantu,",cast:["Allu Arjun"]),
    Movie(MovieTitle: "Shatamanabhavathi", MovieImage: UIImage(named: "Shata")!, releasedYear: "2017", MovieRating: "5", boxOffice: "38", moviePlot: "The movie is set in the backdrop of a small village called Atreyapuram. ",cast: ["Sharwanand"]),
    Movie(MovieTitle: "Bangarraju", MovieImage: UIImage(named: "Bangarraju")!, releasedYear: "2022", MovieRating: "5", boxOffice: "189", moviePlot: "Bangarraju and Satyabhama come down to settle the life of their grandson Chinna Bangarraju and to save the treasure of temple",cast: ["Nagarjuna"]),
    Movie(MovieTitle: "Manam", MovieImage: UIImage(named: "Manam")!, releasedYear: "2014", MovieRating: "3", boxOffice: "167", moviePlot: "Through reincarnation, family members are able to cross generations and meddle in each others' lives.",cast: ["Nagarjuna"])])

let genre2 = Genre(MovieCategory: "Comedy", movies: [
    Movie(MovieTitle: "Miss Shetty Mr Polishetty", MovieImage: UIImage(named: "MM")!, releasedYear: "2023", MovieRating: "7", boxOffice: "70", moviePlot: "two appear to be in different stages of life but somehow connect",cast: ["Naveen Polishetty"]),
    Movie(MovieTitle: "Darling", MovieImage: UIImage(named: "Darling")!, releasedYear: "2010", MovieRating: "7", boxOffice: "150", moviePlot: " when a group of friends celebrate their farewell party. ",cast: ["Kajal,Prabhas"]),
    Movie(MovieTitle: "Happy", MovieImage: UIImage(named: "Happy")!, releasedYear: "2006", MovieRating: "7", boxOffice: "76", moviePlot: "Allu Arjun and Genelia as a comedy trio for the conflict resolution between Genelia's father and the other police guy.",cast: ["Genelia"]),
    Movie(MovieTitle: "Malleswari", MovieImage: UIImage(named: "Malli")!, releasedYear: "2004", MovieRating: "8", boxOffice: "20", moviePlot: "When her father dies, a wealthy heiress is sent to another city to protect her from people who try to harm and manipulate her.",cast: ["Venkatesh"]),
    Movie(MovieTitle: "Kick", MovieImage: UIImage(named: "Kick")!, releasedYear: "2009", MovieRating: "8", boxOffice: "167", moviePlot: "Whatever hero wants to do, he wants to do it with a “Kick” and whatever he does to make a child happy and smile, that is what is important to him",cast: ["Ravi Teja, Ileana"])])

let genre3 = Genre(MovieCategory: "Thriller", movies: [
    Movie(MovieTitle: "Hit", MovieImage: UIImage(named: "Hit")!, releasedYear: "2022", MovieRating: "6", boxOffice: "60", moviePlot: "Vikram Rudraraju (Vishwak Sen), a cop, is suffering from Post-Traumatic Stress Disorder after a dear one was brutally set on fire a few years ago by some savage men.",cast: ["ViskwakSen"]),
    Movie(MovieTitle: "Hit2", MovieImage: UIImage(named: "Hit2")!, releasedYear: "2022", MovieRating: "7", boxOffice: "190", moviePlot: "The city of Vizag is stunned with the brutal murder of a young woman.",cast: ["Adavi Sesh"]),
    Movie(MovieTitle: "Agent Sai Srinivasa Athreya", MovieImage: UIImage(named: "Agent")!, releasedYear: "2019", MovieRating: "4", boxOffice: "450", moviePlot: "It follows a Nellore-based detective whose life runs into danger when he starts investigating the case of a dead body abandoned near a railway track.",cast: ["Naveen Polishetty"]),
    Movie(MovieTitle: "Drishyam", MovieImage: UIImage(named: "Drishyam")!, releasedYear: "2015", MovieRating: "5", boxOffice: "257", moviePlot: "The film tells the story of a Maharashtrian family who live in Goa and whose lives turn upside down",cast: ["Venkatesh,Meena"]),
    Movie(MovieTitle: "Kshanam", MovieImage: UIImage(named: "Kshanam")!, releasedYear: "2016", MovieRating: "3", boxOffice: "167", moviePlot: "Rishi, a non-resident Indian, returns to India to help his ex-lover find her kidnapped daughter.",cast: ["Sesh, Regina"])])

let gen = [genre1,genre2,genre3]
