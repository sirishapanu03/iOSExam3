//
//  UniversityListViewController.swift
//  Panuagnti_UniversityApp
//
//  Created by Sirisha Panuganti on 11/16/23.
//

import UIKit

class UniversityListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return List.list_Array.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let it = universityListTableView.dequeueReusableCell(withIdentifier: "listCell", for: indexPath)
        it.textLabel?.text = List.list_Array[indexPath.row].collegeName
        return it
    }
    

    
    @IBOutlet weak var universityListTableView: UITableView!
    var List = Universities()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        universityListTableView.delegate = self
        universityListTableView.dataSource = self
        self.title = List.domain

    }
    

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "universityInfoSegue"{
        let destination = segue.destination as! UniverstyInfoViewController
        destination.data = List.list_Array[(universityListTableView.indexPathForSelectedRow?.row)!]
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
