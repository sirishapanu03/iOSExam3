//
//  UniverstyInfoViewController.swift
//  Panuagnti_UniversityApp
//
//  Created by Sirisha Panuganti on 11/16/23.
//

import UIKit

class UniverstyInfoViewController: UIViewController {

    var data = UniversityList()
    @IBOutlet weak var universityImageViewController: UIImageView!
    
    @IBOutlet weak var universityInfoOutlet: UITextView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        // Do any additional setup after loading the view.
        universityInfoOutlet.isHidden = true
        self.title = data.collegeName
        self.universityImageViewController.frame.origin.x = view.frame.width
        universityImageViewController.image = UIImage(named: data.collegeImage)
    }
    override func viewDidAppear(_ animated: Bool) {
            UIView.animate(withDuration: 2, animations: {
                self.universityImageViewController.center.x = self.view.frame.width/2
            })
        }
    
    
    @IBAction func showInfoAction(_ sender: Any) {
        universityInfoOutlet.isHidden = false
        universityInfoOutlet.text = data.collegeInfo
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
