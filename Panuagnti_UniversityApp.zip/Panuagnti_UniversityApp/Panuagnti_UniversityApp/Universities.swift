//
//  Universities.swift
//  Panuagnti_UniversityApp
//
//  Created by Sirisha Panuganti on 11/16/23.
//

import Foundation

struct Universities{
    var domain = ""
    var list_Array  : [UniversityList] = []
}

struct UniversityList{
    var collegeName = "";
    var collegeImage = "";
    var collegeInfo = ""
    
}

let domain1 = Universities(domain: "Computer Science",
                           list_Array: [
                            UniversityList(collegeName:"Princeton University",collegeImage:"Princeton",collegeInfo:"The ivy-covered campus of Princeton University, a private institution, is located in the quiet town of Princeton, New Jersey. Princeton was the first university to offer no loan policy to financially needy students, giving grants instead of loans to accepted students who need help paying tuition."),
     
                            UniversityList(collegeName:"Massachusetts Institute of Technology",collegeImage:"Massachusetts",collegeInfo:"The Massachusetts Institute of Technology  is best known for its math, science and engineering education, this private research university also offers architecture, humanities, management and social science programs"),
    
                            UniversityList(collegeName:"Harvard University",collegeImage:"Harvard",collegeInfo:"Harvard University is a private institution in Cambridge, Massachusetts, just outside of Boston. This Ivy League school is the oldest higher education institution in the country and has the largest endowment of any school in the world."),
    
                            UniversityList(collegeName:"Yale University",collegeImage:"Yale",collegeInfo:"Yale University, located in New Haven, Connecticut, offers a small college life with the resources of a major research institution. Yale students are divided into 14 residential colleges that foster a supportive environment for living, learning and socializing."),
    
                            UniversityList(collegeName:"University of Pennsylvania",collegeImage:"Pennsylvania",collegeInfo:"University of Pennsylvania is a private institution in the University City neighborhood of Philadelphia, Pennsylvania. Students can study in one of four schools that grant undergraduate degrees: Arts and Sciences, Nursing, Engineering and Applied Sciences.")])

let domain2 = Universities(domain: "Data Science",
                           list_Array: [
                            UniversityList(collegeName:"California Institute of Technology",collegeImage:"California",collegeInfo:"The California Institute of Technology focuses on science and engineering education and has a low student-to-faculty ratio of 3:1. This private institution in Pasadena, California, is actively involved in research projects with grants from NASA, the National Science Foundation and the U.S"),
    
                            UniversityList(collegeName:"Duke University",collegeImage:"Duke",collegeInfo:"Located in Durham, North Carolina, Duke University is a private institution that has liberal arts and engineering programs for undergraduates. The Duke Blue Devils sports teams have a fierce rivalry with the University of North Carolina—Chapel Hill Tar Heels and are best known for their outstanding Education."),
   
                            UniversityList(collegeName:"Brown University",collegeImage:"Brown",collegeInfo:"At Brown University, undergraduate students are responsible for designing their own academic study with more than 80 concentration programs to choose from. Another unique offering at this private, Ivy League institution in Providence, Rhode Island, is the Program in Liberal Medical Education."),
  
                            UniversityList(collegeName:"Johns Hopkins University",collegeImage:"John",collegeInfo:"Johns Hopkins University is a private institution in Baltimore that offers a wide array of academic programs in the arts, humanities, social and natural sciences, and engineering disciplines."),
  
                            UniversityList(collegeName:"Northwestern University",collegeImage:"Northwestern",collegeInfo:"Northwestern University is a private school in Evanston, Ill., about 30 minutes outside of Chicago. Undergraduate students have about 100 options for majors or can design their own non-traditional degree program."),])

let domain3 = Universities(domain: "IT",
                           list_Array: [
                            UniversityList(collegeName:"Cornell University",collegeImage:"Cornell",collegeInfo:"Cornell University, a private school in Ithaca, New York, has 14 colleges and schools. Each admits its own students, though every graduate receives a degree from Cornell University. The university has more than 1,000 student organizations on campus.."),
    
                            UniversityList(collegeName:"University of California, Berkeley",collegeImage:"UCB",collegeInfo:"The University of California, Berkeley overlooks the San Francisco Bay in Berkeley, Calif. Students at this public school have more than 1,000 groups to get involved in, including more than 60 fraternity and sorority chapters"),
    
                            UniversityList(collegeName:"University of California, Los Angeles",collegeImage:"UCL",collegeInfo:"The University of California, Los Angeles is just five miles away from the Pacific Ocean. The public institution offers 5,000 courses, 140 bachelor's degree programs and 97 minors."),
   
                            UniversityList(collegeName:"Rice University",collegeImage:"Rice",collegeInfo:"Rice University is located in the heart of the Museum District in Houston, TX. The private institution has a need-blind admissions policy and meets the full demonstrated need of any accepted student who requires help paying tuition."),
    
                            UniversityList(collegeName:"Dartmouth College",collegeImage:"Dartmouth",collegeInfo:"Dartmouth College, a private institution in Hanover, New Hampshire, uses quarters, not semesters, to divide the school year. Among more than 300 student organizations at Dartmouth is the Outing Club, the nation's oldest and largest collegiate club of its kind, which offers outdoor activities.")])

let domain4 = Universities(domain: "Biology",
                           list_Array: [
                            UniversityList(collegeName:"Emory University",collegeImage:"Emory",collegeInfo:"Students can begin their education at the school's main location in a suburb of Atlanta, known as Emory College, or at Oxford College, a smaller campus about 40 miles away. This private institution offers about 70 majors in the arts and sciences, as well as degrees in business administration."),
    
                            UniversityList(collegeName:"Vanderbilt University",collegeImage:"Vanderbilt",collegeInfo:"Vanderbilt University is a private institution in Nashville, Tenn. with four undergraduate colleges: the College of Arts and Science, the School of Engineering, Peabody College, and the Blair School of Music. About 40 percent of Vanderbilt students participate in Greek life."),
    
                            UniversityList(collegeName:"Carnegie Mellon University",collegeImage:"Carnegie",collegeInfo:"Carnegie Mellon University, a private institution in Pittsburgh, is the country’s only school founded by industrialist and philanthropist Andrew Carnegie. The school specializes in academic areas including engineering, business, computer science and fine arts."),
    
                            UniversityList(collegeName:"University of Notre Dame",collegeImage:"Notre",collegeInfo:"The University of Notre Dame is a private, independent, Catholic institution in South Bend, Ind. Notre Dame’s athletic teams, known as the Fighting Irish, play in the NCAA Division I and are particularly competitive on the football."),
    
                            UniversityList(collegeName:"Washington University in St. Louis",collegeImage:"Washington",collegeInfo:"Students can study architecture, art, arts and sciences, business, and engineering at Washington University in St. Louis, a private research institution in Missouri. Outside of class, about 35 percent of the student body is involved in Greek life.")])

let universityList:[Universities] = [domain1,domain2,domain3,domain4]



