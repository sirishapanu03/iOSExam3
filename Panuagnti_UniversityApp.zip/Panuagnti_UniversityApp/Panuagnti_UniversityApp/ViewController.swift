//
//  ViewController.swift
//  Panuagnti_UniversityApp
//
//  Created by Sirisha Panuganti on 11/16/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return unversity.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let Mycell = universitiesTableView.dequeueReusableCell(withIdentifier: "domainCell", for: indexPath)
        Mycell.textLabel?.text = unversity[indexPath.row].domain
        return Mycell
    }
    

    @IBOutlet weak var universitiesTableView: UITableView!
    
    var unversity = universityList
   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        universitiesTableView.delegate = self
        universitiesTableView.dataSource = self
        self.title = "Domains"
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "listsSegue"{
        let destination = segue.destination as! UniversityListViewController
        destination.List = unversity[(universitiesTableView.indexPathForSelectedRow?.row)!]
        }

    }
}

